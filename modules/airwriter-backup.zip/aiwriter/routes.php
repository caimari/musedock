<?php
use Screenart\Musedock\Route;

// Cargar controladores
require_once __DIR__ . '/controllers/AdminController.php';

// Ruta para servir el archivo JS del plugin
Route::get('/modules/aiwriter/assets/js/tiny-ai-plugin.js', function() {
    $file = __DIR__ . '/assets/js/tiny-ai-plugin.js';
    if (file_exists($file)) {
        header('Content-Type: application/javascript');
        echo file_get_contents($file);
        exit;
    } else {
        http_response_code(404);
        echo "Plugin JS file not found";
        exit;
    }
});

// ---------- Rutas del panel del superadmin ----------
Route::get('/musedock/aiwriter/settings', 'AIWriter\\AdminController@settings')
    ->middleware('superadmin');
Route::post('/musedock/aiwriter/settings/update', 'AIWriter\\AdminController@updateSettings')
    ->middleware('superadmin');

// ---------- Rutas para los paneles de admin de tenants ----------
// Intentar obtener la ruta admin del tenant
$tenantAdminPath = isset($GLOBALS['tenant']['admin_path']) ? 
    '/' . trim($GLOBALS['tenant']['admin_path'], '/') : 
    '/admin';

// Rutas tenant admin para configuración
Route::get("$tenantAdminPath/aiwriter/settings", 'AIWriter\\AdminController@settings')
    ->middleware(['auth', 'permission:aiwriter.settings']);
Route::post("$tenantAdminPath/aiwriter/settings/update", 'AIWriter\\AdminController@updateSettings')
    ->middleware(['auth', 'permission:aiwriter.settings']);