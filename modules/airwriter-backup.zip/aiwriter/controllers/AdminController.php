<?php
namespace AIWriter;

use Screenart\Musedock\View;
use Screenart\Musedock\Database;
use Screenart\Musedock\Logger;

class AdminController
{
    private $isSuperAdmin = false;
    
    public function __construct()
    {
        // Comprobar si es superadmin o admin de tenant
        $this->isSuperAdmin = isset($_SESSION['super_admin']);
    }
    
    /**
     * Muestra la página de configuración
     */
    public function settings()
    {
        $tenantId = tenant_id();
        
        // Datos por defecto (para evitar errores)
        $defaultSettings = [
            'ai_default_provider' => '',
            'ai_daily_token_limit' => '0',
            'ai_log_all_prompts' => '1'
        ];
        
        $settings = $defaultSettings;
        $providers = [];
        
        try {
            // Obtener configuraciones
            $query = "SELECT setting_key, setting_value FROM ai_settings WHERE tenant_id ";
            $query .= $tenantId ? "= :tenant_id" : "IS NULL";
            $params = $tenantId ? ['tenant_id' => $tenantId] : [];
            
            $result = Database::query($query, $params)->fetchAll();
            
            // Convertir resultados a array asociativo
            foreach ($result as $row) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
            
            // Obtener proveedores disponibles
            $providerQuery = "SELECT * FROM ai_providers WHERE active = 1";
            if ($tenantId) {
                $providerQuery .= " AND (tenant_id = :tenant_id OR (tenant_id IS NULL AND system_wide = 1))";
                $providerParams = ['tenant_id' => $tenantId];
            } else {
                $providerQuery .= " AND tenant_id IS NULL";
                $providerParams = [];
            }
            $providerQuery .= " ORDER BY name ASC";
            
            $providers = Database::query($providerQuery, $providerParams)->fetchAll();
        } catch (\Exception $e) {
            // Registrar el error pero mantener los valores por defecto
            Logger::error("Error en AIWriter settings: " . $e->getMessage());
        }
        
        // Renderizar vista usando el método adecuado según tipo de usuario
        if ($this->isSuperAdmin) {
            return View::renderSuperadmin('aiwriter.settings', [
                'title' => 'Configuración de AI Writer',
                'settings' => $settings,
                'providers' => $providers
            ]);
        } else {
            return View::renderTenantAdmin('aiwriter.admin.settings', [
                'title' => 'Configuración de AI Writer',
                'settings' => $settings,
                'providers' => $providers
            ]);
        }
    }
    
    /**
     * Actualiza la configuración
     */
    public function updateSettings()
    {
        $tenantId = tenant_id();
        
        try {
            // Configuraciones a actualizar
            $settings = [
                'ai_default_provider' => $_POST['default_provider'] ?? '',
                'ai_daily_token_limit' => $_POST['daily_token_limit'] ?? '0',
                'ai_log_all_prompts' => isset($_POST['log_all_prompts']) ? '1' : '0'
            ];
            
            // Guardar cada configuración
            foreach ($settings as $key => $value) {
                // Verificar si ya existe
                $existsQuery = "SELECT COUNT(*) FROM ai_settings WHERE setting_key = :key AND tenant_id ";
                $existsQuery .= $tenantId ? "= :tenant_id" : "IS NULL";
                $existsParams = ['key' => $key];
                if ($tenantId) {
                    $existsParams['tenant_id'] = $tenantId;
                }
                
                $exists = Database::query($existsQuery, $existsParams)->fetchColumn();
                
                if ($exists) {
                    // Actualizar configuración existente
                    $updateQuery = "UPDATE ai_settings SET setting_value = :value, updated_at = NOW() 
                                  WHERE setting_key = :key AND tenant_id ";
                    $updateQuery .= $tenantId ? "= :tenant_id" : "IS NULL";
                    
                    $updateParams = [
                        'key' => $key,
                        'value' => $value
                    ];
                    
                    if ($tenantId) {
                        $updateParams['tenant_id'] = $tenantId;
                    }
                    
                    Database::query($updateQuery, $updateParams);
                } else {
                    // Insertar nueva configuración
                    $insertQuery = "INSERT INTO ai_settings (setting_key, setting_value, tenant_id, created_at, updated_at)
                                  VALUES (:key, :value, " . ($tenantId ? ":tenant_id" : "NULL") . ", NOW(), NOW())";
                    
                    $insertParams = [
                        'key' => $key,
                        'value' => $value
                    ];
                    
                    if ($tenantId) {
                        $insertParams['tenant_id'] = $tenantId;
                    }
                    
                    Database::query($insertQuery, $insertParams);
                }
            }
            
            // Establecer mensaje de éxito en la sesión
            flash('success', 'Configuración actualizada correctamente');
        } catch (\Exception $e) {
            // Capturar cualquier excepción
            Logger::error("Error al actualizar la configuración: " . $e->getMessage());
            flash('error', 'Error al actualizar la configuración: ' . $e->getMessage());
        }
        
        // Redireccionar mediante encabezado HTTP en lugar de usar función redirect()
        $redirectUrl = $this->isSuperAdmin 
            ? '/musedock/aiwriter/settings' 
            : admin_url() . '/aiwriter/settings';
        
        header('Location: ' . $redirectUrl);
        exit; // Importante para detener la ejecución después del redirect
    }
}