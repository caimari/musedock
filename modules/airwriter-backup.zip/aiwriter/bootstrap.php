<?php
// Evitar cargas múltiples
if (defined('BOOTSTRAP_AIWRITER')) return;
define('BOOTSTRAP_AIWRITER', true);

use Screenart\Musedock\Database;

/**
 * Verificar si el módulo está activo para agregar el plugin de TinyMCE
 */
if (!function_exists('aiwriter_is_active')) {
    function aiwriter_is_active() {
        try {
            $tenantId = tenant_id();
            
            if ($tenantId !== null) {
                $query = "
                    SELECT m.active, m.cms_enabled, tm.enabled 
                    FROM modules m
                    LEFT JOIN tenant_modules tm ON tm.module_id = m.id AND tm.tenant_id = :tenant_id
                    WHERE m.slug = 'aiwriter'
                ";
                $module = Database::query($query, ['tenant_id' => $tenantId])->fetch();
                
                return $module && $module['active'] && ($module['enabled'] ?? false);
            } else {
                $query = "SELECT active, cms_enabled FROM modules WHERE slug = 'aiwriter'";
                $module = Database::query($query)->fetch();
                
                return $module && $module['active'] && $module['cms_enabled'];
            }
        } catch (\Exception $e) {
            return false;
        }
    }
}

/**
 * Modificar la inicialización de TinyMCE para incluir el plugin AIWriter
 */
if (aiwriter_is_active()) {
    // Registrar un hook global para TinyMCE
    $GLOBALS['TINYMCE_PLUGINS'] = $GLOBALS['TINYMCE_PLUGINS'] ?? [];
    $GLOBALS['TINYMCE_PLUGINS'][] = [
        'name' => 'aiwriter',
        'url' => '/modules/aiwriter/assets/js/tiny-ai-plugin.js',
        'toolbar' => 'aiwritermenu'
    ];
}

/**
 * Registrar menú de admin
 */
// Añadir al menú del superadmin
if (isset($_SESSION['super_admin'])) {
    // Para panel de superadmin
    $GLOBALS['ADMIN_MENU'] = $GLOBALS['ADMIN_MENU'] ?? [];
    
    $GLOBALS['ADMIN_MENU'][] = [
        'title' => 'AI Writer',
        'icon' => 'magic',
        'children' => [
            [
                'title' => 'Configuración',
                'url' => '/musedock/aiwriter/settings'
            ]
        ]
    ];
}

// Añadir al menú de admin de tenant
if (isset($_SESSION['admin'])) {
    // Para panel de admin de tenant
    $GLOBALS['ADMIN_MENU'] = $GLOBALS['ADMIN_MENU'] ?? [];
    $adminPath = admin_url();
    
    $GLOBALS['ADMIN_MENU'][] = [
        'title' => 'AI Writer',
        'icon' => 'magic',
        'children' => [
            [
                'title' => 'Configuración',
                'url' => "$adminPath/aiwriter/settings"
            ]
        ]
    ];
}