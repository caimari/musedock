<?php
/**
 * Migration: Create cloudflare_accounts table
 * Plugin: Caddy Domain Manager v1.2.0
 * Compatible with: MySQL/MariaDB + PostgreSQL
 */

namespace CaddyDomainManager\Migrations;

use Screenart\Musedock\Database;
use PDO;

class CreateCloudflareAccountsTable
{
    public function up(): void
    {
        $pdo = Database::connect();
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);

        if ($driver === 'mysql') {
            $this->upMySQL($pdo);
        } else {
            $this->upPostgreSQL($pdo);
        }

        echo "  [Caddy Domain Manager] cloudflare_accounts table created\n";
    }

    private function upMySQL(PDO $pdo): void
    {
        // Check if table already exists
        $stmt = $pdo->query("SHOW TABLES LIKE 'cloudflare_accounts'");
        if ($stmt->fetch()) {
            echo "  [Caddy Domain Manager] cloudflare_accounts table already exists, skipping...\n";
            return;
        }

        $pdo->exec("
            CREATE TABLE `cloudflare_accounts` (
                `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `name` VARCHAR(255) NOT NULL,
                `api_token` TEXT NOT NULL COMMENT 'AES-256-CBC encrypted',
                `account_id` VARCHAR(255) NOT NULL DEFAULT '',
                `role` ENUM('primary', 'domains', 'readonly') NOT NULL DEFAULT 'domains',
                `is_default_for_new_domains` TINYINT(1) NOT NULL DEFAULT 0,
                `ssl_mode` VARCHAR(20) NOT NULL DEFAULT 'full',
                `enabled` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");

        $pdo->exec("CREATE INDEX `idx_cf_accounts_role` ON `cloudflare_accounts`(`role`)");
        $pdo->exec("CREATE INDEX `idx_cf_accounts_enabled` ON `cloudflare_accounts`(`enabled`)");
    }

    private function upPostgreSQL(PDO $pdo): void
    {
        // Check if table already exists
        $stmt = $pdo->prepare("
            SELECT table_name FROM information_schema.tables
            WHERE table_name = 'cloudflare_accounts' AND table_schema = 'public'
        ");
        $stmt->execute();
        if ($stmt->fetch()) {
            echo "  [Caddy Domain Manager] cloudflare_accounts table already exists, skipping...\n";
            return;
        }

        $pdo->exec("
            CREATE TABLE cloudflare_accounts (
                id SERIAL PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                api_token TEXT NOT NULL,
                account_id VARCHAR(255) NOT NULL DEFAULT '',
                role VARCHAR(20) NOT NULL DEFAULT 'domains',
                is_default_for_new_domains SMALLINT NOT NULL DEFAULT 0,
                ssl_mode VARCHAR(20) NOT NULL DEFAULT 'full',
                enabled SMALLINT NOT NULL DEFAULT 1,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        ");

        $pdo->exec("
            ALTER TABLE cloudflare_accounts ADD CONSTRAINT chk_cf_account_role
            CHECK (role IN ('primary', 'domains', 'readonly'))
        ");

        $pdo->exec("CREATE INDEX idx_cf_accounts_role ON cloudflare_accounts(role)");
        $pdo->exec("CREATE INDEX idx_cf_accounts_enabled ON cloudflare_accounts(enabled)");
    }

    public function down(): void
    {
        $pdo = Database::connect();
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);

        if ($driver === 'mysql') {
            $pdo->exec("DROP TABLE IF EXISTS `cloudflare_accounts`");
        } else {
            $pdo->exec("DROP TABLE IF EXISTS cloudflare_accounts");
        }

        echo "  [Caddy Domain Manager] cloudflare_accounts table dropped\n";
    }
}
