@extends('layouts.app')

@section('title', 'Cloudflare Accounts')

@section('content')
<div class="app-content">
    <div class="container-fluid">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h2><i class="bi bi-cloud-fill"></i> Cloudflare Accounts</h2>
                <p class="text-muted mb-0">Multi-account management for Caddy Domain Manager</p>
            </div>
            <div class="d-flex gap-2">
                <a href="/musedock/domain-manager" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> Domain Manager
                </a>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addAccountModal">
                    <i class="bi bi-plus-lg"></i> Add Account
                </button>
            </div>
        </div>

        @if(!empty($flash))
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <i class="bi bi-info-circle"></i> {{ $flash }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        @endif

        @if($hasEnvFallback && empty($accounts))
        <div class="alert alert-warning">
            <i class="bi bi-exclamation-triangle"></i>
            <strong>Using .env fallback.</strong> Cloudflare tokens are read from environment variables.
            They will be auto-migrated to the database (encrypted) when you first visit this page with valid tokens.
        </div>
        @endif

        {{-- Accounts Table --}}
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="text-muted">{{ count($accounts) }} account(s) configured</span>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:50px;">ID</th>
                            <th>Name</th>
                            <th>Role</th>
                            <th>Account ID</th>
                            <th>Token</th>
                            <th>SSL</th>
                            <th style="width:80px;">Default</th>
                            <th style="width:80px;">Status</th>
                            <th style="width:160px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($accounts as $account)
                        <tr id="account-row-{{ $account['id'] }}">
                            <td><code>{{ $account['id'] }}</code></td>
                            <td><strong>{{ $account['name'] }}</strong></td>
                            <td>
                                @if($account['role'] === 'primary')
                                    <span class="badge bg-primary">Primary</span>
                                @elseif($account['role'] === 'domains')
                                    <span class="badge bg-success">Domains</span>
                                @else
                                    <span class="badge bg-secondary">Read-only</span>
                                @endif
                            </td>
                            <td><code class="small">{{ $account['account_id'] ?: '—' }}</code></td>
                            <td><code class="small">{{ $account['api_token_masked'] }}</code></td>
                            <td><span class="badge bg-info text-dark">{{ $account['ssl_mode'] }}</span></td>
                            <td class="text-center">
                                @if($account['is_default_for_new_domains'])
                                    <i class="bi bi-star-fill text-warning" title="Default for new domains"></i>
                                @else
                                    <button class="btn btn-sm btn-outline-warning" onclick="setDefault({{ $account['id'] }})" title="Set as default">
                                        <i class="bi bi-star"></i>
                                    </button>
                                @endif
                            </td>
                            <td class="text-center">
                                @if($account['enabled'])
                                    <span class="badge bg-success cursor-pointer" onclick="toggleEnabled({{ $account['id'] }})" style="cursor:pointer;" title="Click to disable">Active</span>
                                @else
                                    <span class="badge bg-danger cursor-pointer" onclick="toggleEnabled({{ $account['id'] }})" style="cursor:pointer;" title="Click to enable">Disabled</span>
                                @endif
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-info" onclick="testConnection({{ $account['id'] }})" title="Test connection">
                                        <i class="bi bi-wifi"></i>
                                    </button>
                                    <button class="btn btn-outline-primary" onclick="editAccount({{ json_encode($account) }})" title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <button class="btn btn-outline-danger" onclick="deleteAccount({{ $account['id'] }}, '{{ addslashes($account['name']) }}')" title="Delete">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="9" class="text-center text-muted py-4">
                                No Cloudflare accounts configured.<br>
                                <small>Add one manually or configure tokens in .env to auto-migrate.</small>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Info card --}}
        <div class="card mt-3">
            <div class="card-body small text-muted">
                <h6 class="card-title"><i class="bi bi-info-circle"></i> How it works</h6>
                <ul class="mb-0">
                    <li><strong>Primary</strong> — Main Cloudflare account (DNS lookups, existing zones). Usually your own domain account.</li>
                    <li><strong>Domains</strong> — Account used to create new zones for custom domains (Full Setup / NS change).</li>
                    <li><strong>Read-only</strong> — Only used for zone lookups, never creates zones.</li>
                    <li><i class="bi bi-star-fill text-warning"></i> <strong>Default</strong> — New domains will be created in this account.</li>
                    <li>Tokens are encrypted with <strong>AES-256-CBC</strong> before storing in the database.</li>
                    <li>When provisioning a domain, <strong>all active accounts</strong> are checked for existing zones before creating a new one.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

{{-- Add/Edit Account Modal --}}
<div class="modal fade" id="addAccountModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="accountModalTitle">Add Cloudflare Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="accountId" value="">
                <div class="mb-3">
                    <label class="form-label">Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="accountName" placeholder="e.g. Primary, Custom Domains, Client X">
                </div>
                <div class="mb-3">
                    <label class="form-label">API Token <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="accountApiToken" placeholder="Cloudflare API Token">
                    <div class="form-text">Will be encrypted with AES-256-CBC. Leave empty when editing to keep current token.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Account ID</label>
                    <input type="text" class="form-control" id="accountAccountId" placeholder="Cloudflare Account ID">
                    <div class="form-text">Found in Cloudflare dashboard → Overview → right sidebar.</div>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" id="accountRole">
                            <option value="primary">Primary</option>
                            <option value="domains" selected>Domains</option>
                            <option value="readonly">Read-only</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">SSL Mode</label>
                        <select class="form-select" id="accountSslMode">
                            <option value="full" selected>Full</option>
                            <option value="full_strict">Full (Strict)</option>
                            <option value="flexible">Flexible</option>
                            <option value="off">Off</option>
                        </select>
                    </div>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="accountIsDefault">
                    <label class="form-check-label" for="accountIsDefault">
                        Default for new domains
                    </label>
                </div>
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="accountEnabled" checked>
                    <label class="form-check-label" for="accountEnabled">
                        Enabled
                    </label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-info" onclick="testTokenFromModal()">
                    <i class="bi bi-wifi"></i> Test Token
                </button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="saveAccount()">
                    <i class="bi bi-check-lg"></i> Save
                </button>
            </div>
        </div>
    </div>
</div>

<script>
const BASE_URL = '/musedock/plugins/caddy-domain-manager/cloudflare-accounts';

function showToast(msg, type = 'success') {
    if (typeof Swal !== 'undefined') {
        Swal.fire({ toast: true, position: 'top-end', icon: type, title: msg, showConfirmButton: false, timer: 3000 });
    } else {
        alert(msg);
    }
}

function resetModal() {
    document.getElementById('accountId').value = '';
    document.getElementById('accountName').value = '';
    document.getElementById('accountApiToken').value = '';
    document.getElementById('accountAccountId').value = '';
    document.getElementById('accountRole').value = 'domains';
    document.getElementById('accountSslMode').value = 'full';
    document.getElementById('accountIsDefault').checked = false;
    document.getElementById('accountEnabled').checked = true;
    document.getElementById('accountModalTitle').textContent = 'Add Cloudflare Account';
}

// Reset modal when opening for new account
document.getElementById('addAccountModal').addEventListener('show.bs.modal', function (e) {
    if (!e.relatedTarget || !e.relatedTarget.dataset.edit) {
        resetModal();
    }
});

function editAccount(account) {
    document.getElementById('accountId').value = account.id;
    document.getElementById('accountName').value = account.name;
    document.getElementById('accountApiToken').value = '';
    document.getElementById('accountAccountId').value = account.account_id || '';
    document.getElementById('accountRole').value = account.role;
    document.getElementById('accountSslMode').value = account.ssl_mode || 'full';
    document.getElementById('accountIsDefault').checked = !!parseInt(account.is_default_for_new_domains);
    document.getElementById('accountEnabled').checked = !!parseInt(account.enabled);
    document.getElementById('accountModalTitle').textContent = 'Edit: ' + account.name;

    new bootstrap.Modal(document.getElementById('addAccountModal')).show();
}

function saveAccount() {
    const id = document.getElementById('accountId').value;
    const formData = new FormData();
    formData.append('name', document.getElementById('accountName').value);
    formData.append('api_token', document.getElementById('accountApiToken').value);
    formData.append('account_id', document.getElementById('accountAccountId').value);
    formData.append('role', document.getElementById('accountRole').value);
    formData.append('ssl_mode', document.getElementById('accountSslMode').value);
    formData.append('is_default_for_new_domains', document.getElementById('accountIsDefault').checked ? '1' : '');
    formData.append('enabled', document.getElementById('accountEnabled').checked ? '1' : '');

    const url = id ? `${BASE_URL}/${id}/update` : BASE_URL;

    fetch(url, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast(data.message);
                setTimeout(() => location.reload(), 800);
            } else {
                showToast(data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed: ' + err.message, 'error'));
}

function deleteAccount(id, name) {
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Delete account?',
            text: `Delete "${name}"? This cannot be undone.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'Delete',
        }).then(result => {
            if (result.isConfirmed) doDelete(id);
        });
    } else if (confirm(`Delete "${name}"?`)) {
        doDelete(id);
    }
}

function doDelete(id) {
    fetch(`${BASE_URL}/${id}/delete`, { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast(data.message);
                document.getElementById('account-row-' + id)?.remove();
            } else {
                showToast(data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed', 'error'));
}

function testConnection(accountDbId) {
    const formData = new FormData();
    formData.append('account_id_db', accountDbId);

    fetch(`${BASE_URL}/test-connection`, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast('Connection OK — Token status: ' + (data.status || 'active'), 'success');
            } else {
                showToast('Connection failed: ' + data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed', 'error'));
}

function testTokenFromModal() {
    const token = document.getElementById('accountApiToken').value;
    const accountDbId = document.getElementById('accountId').value;
    const formData = new FormData();

    if (token) {
        formData.append('api_token', token);
    } else if (accountDbId) {
        formData.append('account_id_db', accountDbId);
    } else {
        showToast('Enter an API token first', 'warning');
        return;
    }

    fetch(`${BASE_URL}/test-connection`, { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast('Token valid — Status: ' + (data.status || 'active'), 'success');
            } else {
                showToast('Token invalid: ' + data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed', 'error'));
}

function toggleEnabled(id) {
    fetch(`${BASE_URL}/${id}/toggle`, { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast(data.message);
                setTimeout(() => location.reload(), 500);
            } else {
                showToast(data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed', 'error'));
}

function setDefault(id) {
    fetch(`${BASE_URL}/${id}/set-default`, { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                showToast(data.message);
                setTimeout(() => location.reload(), 500);
            } else {
                showToast(data.error, 'error');
            }
        })
        .catch(err => showToast('Request failed', 'error'));
}
</script>
@endsection
