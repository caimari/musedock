<?php
/**
 * Routes for Caddy Domain Manager plugin
 *
 * Este archivo se carga desde routes/superadmin.php para plugins activos
 */

// Verificar contexto de ejecución
if (!defined('APP_ROOT')) {
    exit('No direct access allowed');
}

use Screenart\Musedock\Route;

// Registrar autoloader del plugin si no está cargado
spl_autoload_register(function ($class) {
    $prefix = 'CaddyDomainManager\\';
    $baseDir = __DIR__ . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// ============================================
// CADDY DOMAIN MANAGER ROUTES
// ============================================

// Listar dominios
Route::get('/musedock/domain-manager', 'CaddyDomainManager\Controllers\DomainManagerController@index')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.index');

// Crear nuevo dominio
Route::get('/musedock/domain-manager/create', 'CaddyDomainManager\Controllers\DomainManagerController@create')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.create');

Route::post('/musedock/domain-manager', 'CaddyDomainManager\Controllers\DomainManagerController@store')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.store');

// Editar dominio
Route::get('/musedock/domain-manager/{id}/edit', 'CaddyDomainManager\Controllers\DomainManagerController@edit')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.edit');

Route::put('/musedock/domain-manager/{id}', 'CaddyDomainManager\Controllers\DomainManagerController@update')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.update');

// Ruta POST alternativa para update (compatibilidad con formularios HTML)
Route::post('/musedock/domain-manager/{id}/update', 'CaddyDomainManager\Controllers\DomainManagerController@update')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.update.post');

// Eliminar dominio
Route::delete('/musedock/domain-manager/{id}', 'CaddyDomainManager\Controllers\DomainManagerController@destroy')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.destroy');

// Eliminar dominio con verificación de contraseña (AJAX)
Route::post('/musedock/domain-manager/{id}/delete-secure', 'CaddyDomainManager\Controllers\DomainManagerController@destroyWithPassword')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.destroy.secure');

// Eliminar domain order (registro de cliente) con verificación de contraseña (AJAX)
// NOTA: No elimina el dominio de OpenProvider (solo puede expirar), solo BD local y Cloudflare opcional
Route::post('/musedock/domain-manager/order/{id}/delete-secure', 'CaddyDomainManager\Controllers\DomainManagerController@destroyDomainOrderWithPassword')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.order.destroy.secure');

// Reconfigurar en Caddy
Route::post('/musedock/domain-manager/{id}/reconfigure', 'CaddyDomainManager\Controllers\DomainManagerController@reconfigure')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.reconfigure');

// Verificar estado (AJAX)
Route::get('/musedock/domain-manager/{id}/status', 'CaddyDomainManager\Controllers\DomainManagerController@checkStatus')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.status');

// Regenerar permisos del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/regenerate-permissions', 'CaddyDomainManager\Controllers\DomainManagerController@regeneratePermissions')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.regenerate-permissions');

// Regenerar menús del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/regenerate-menus', 'CaddyDomainManager\Controllers\DomainManagerController@regenerateMenus')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.regenerate-menus');

// Regenerar módulos del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/regenerate-modules', 'CaddyDomainManager\Controllers\DomainManagerController@regenerateModules')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.regenerate-modules');

// Regenerar idiomas del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/regenerate-languages', 'CaddyDomainManager\Controllers\DomainManagerController@regenerateLanguages')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.regenerate-languages');

// Vincular dominio existente de Cloudflare (AJAX)
Route::post('/musedock/domain-manager/{id}/link-cloudflare', 'CaddyDomainManager\Controllers\DomainManagerController@linkCloudflareZone')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.link-cloudflare');

// Site Settings del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/site-settings', 'CaddyDomainManager\Controllers\DomainManagerController@updateSiteSettings')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.site-settings');

// Eliminar logo del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/delete-logo', 'CaddyDomainManager\Controllers\DomainManagerController@deleteTenantLogo')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.delete-logo');

// Eliminar favicon del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/delete-favicon', 'CaddyDomainManager\Controllers\DomainManagerController@deleteTenantFavicon')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.delete-favicon');

// SEO & Social Settings del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/seo-settings', 'CaddyDomainManager\Controllers\DomainManagerController@updateSeoSettings')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.seo-settings');

// Eliminar imagen OG del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/delete-og-image', 'CaddyDomainManager\Controllers\DomainManagerController@deleteTenantOgImage')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.delete-og-image');

// Blog Settings del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/blog-settings', 'CaddyDomainManager\Controllers\DomainManagerController@updateBlogSettings')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.blog-settings');

// Perfil de autor del admin root (AJAX)
Route::post('/musedock/domain-manager/{id}/author-profile', 'CaddyDomainManager\Controllers\DomainManagerController@updateAuthorProfile')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.author-profile');

// Custom CSS/JS para un tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/custom-code', 'CaddyDomainManager\Controllers\DomainManagerController@updateCustomCode')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.custom-code');

// Auto-categorizar y etiquetar posts con IA (AJAX)
Route::post('/musedock/domain-manager/{id}/auto-tag', 'CaddyDomainManager\Controllers\DomainManagerController@autoTagPosts')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.auto-tag');

// Toggle plugin compartido para un tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/toggle-plugin', 'CaddyDomainManager\Controllers\DomainManagerController@toggleTenantPlugin')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.toggle-plugin');

// Cloudflare Settings (AJAX)
Route::post('/musedock/domain-manager/cloudflare/verify-token', 'CaddyDomainManager\Controllers\DomainManagerController@verifyCloudflareToken')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.cf-verify');

Route::post('/musedock/domain-manager/cloudflare/save-token', 'CaddyDomainManager\Controllers\DomainManagerController@saveCloudflareToken')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.cf-save');

// Domain Aliases (AJAX)
Route::get('/musedock/domain-manager/{id}/aliases', 'CaddyDomainManager\Controllers\DomainManagerController@getAliases')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.aliases');

Route::post('/musedock/domain-manager/{id}/add-alias', 'CaddyDomainManager\Controllers\DomainManagerController@addAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.add-alias');

Route::post('/musedock/domain-manager/{id}/remove-alias', 'CaddyDomainManager\Controllers\DomainManagerController@removeAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.remove-alias');

// Toggle Cloudflare Proxy (AJAX)
Route::post('/musedock/domain-manager/{id}/toggle-proxy', 'CaddyDomainManager\Controllers\DomainManagerController@toggleCloudflareProxy')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.toggle-proxy');

// Check real Cloudflare proxy status (AJAX)
Route::get('/musedock/domain-manager/{id}/check-proxy', 'CaddyDomainManager\Controllers\DomainManagerController@checkProxyStatus')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.check-proxy');

// Toggle Cloudflare proxy for any domain (AJAX)
Route::post('/musedock/domain-manager/toggle-domain-proxy', 'CaddyDomainManager\Controllers\DomainManagerController@toggleDomainProxy')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.toggle-domain-proxy');

// Cambiar password del admin del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/change-admin-password', 'CaddyDomainManager\Controllers\DomainManagerController@changeAdminPassword')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.change-admin-password');

// Actualizar email/nombre del admin del tenant (AJAX)
Route::post('/musedock/domain-manager/{id}/update-admin', 'CaddyDomainManager\Controllers\DomainManagerController@updateAdminField')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.update-admin');

Route::post('/musedock/domain-manager/{id}/save-admin', 'CaddyDomainManager\Controllers\DomainManagerController@saveAdmin')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.save-admin');

// Crear subdominio FREE manual (superadmin)
Route::post('/musedock/domain-manager/create-free', 'CaddyDomainManager\Controllers\DomainManagerController@createFreeSubdomain')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.create-free');

// ============================================
// STANDALONE ALIAS MANAGEMENT ROUTES
// ============================================
Route::get('/musedock/domain-manager/create-alias', 'CaddyDomainManager\Controllers\DomainManagerController@createAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.create-alias');

Route::post('/musedock/domain-manager/store-alias', 'CaddyDomainManager\Controllers\DomainManagerController@storeAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.store-alias');

Route::get('/musedock/domain-manager/alias/{id}/edit', 'CaddyDomainManager\Controllers\DomainManagerController@editAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.edit-alias');

Route::post('/musedock/domain-manager/alias/{id}/update', 'CaddyDomainManager\Controllers\DomainManagerController@updateAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.update-alias');

Route::post('/musedock/domain-manager/alias/{id}/recreate-route', 'CaddyDomainManager\Controllers\DomainManagerController@recreateAliasRoute')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.recreate-alias-route');

Route::post('/musedock/domain-manager/alias/{id}/delete', 'CaddyDomainManager\Controllers\DomainManagerController@deleteAlias')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.delete-alias');

// ============================================
// STANDALONE REDIRECT MANAGEMENT ROUTES
// ============================================
Route::get('/musedock/domain-manager/create-redirect', 'CaddyDomainManager\Controllers\DomainManagerController@createRedirect')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.create-redirect');

Route::post('/musedock/domain-manager/store-redirect', 'CaddyDomainManager\Controllers\DomainManagerController@storeRedirect')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.store-redirect');

Route::get('/musedock/domain-manager/redirect/{id}/edit', 'CaddyDomainManager\Controllers\DomainManagerController@editRedirect')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.edit-redirect');

Route::post('/musedock/domain-manager/redirect/{id}/update', 'CaddyDomainManager\Controllers\DomainManagerController@updateRedirect')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.update-redirect');

Route::post('/musedock/domain-manager/redirect/{id}/delete', 'CaddyDomainManager\Controllers\DomainManagerController@deleteRedirect')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.delete-redirect');

// Listado de clientes (customers)
Route::get('/musedock/domain-manager/customers', 'Cloud\Controllers\Tenant\AdminCustomerController@index')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.customers');

// ============================================
// EMAIL ROUTING MANAGEMENT ROUTES
// ============================================

// Panel de gestión de Email Routing
Route::get('/musedock/domain-manager/{id}/email-routing', 'CaddyDomainManager\Controllers\EmailRoutingController@index')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.index');

// Activar Email Routing
Route::post('/musedock/domain-manager/{id}/email-routing/enable', 'CaddyDomainManager\Controllers\EmailRoutingController@enable')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.enable');

// Desactivar Email Routing
Route::post('/musedock/domain-manager/{id}/email-routing/disable', 'CaddyDomainManager\Controllers\EmailRoutingController@disable')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.disable');

// Crear regla de forwarding
Route::post('/musedock/domain-manager/{id}/email-routing/rules', 'CaddyDomainManager\Controllers\EmailRoutingController@createRule')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.create-rule');

// Eliminar regla de forwarding
Route::post('/musedock/domain-manager/{id}/email-routing/rules/{ruleId}/delete', 'CaddyDomainManager\Controllers\EmailRoutingController@deleteRule')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.delete-rule');

// Toggle estado de regla (enable/disable)
Route::post('/musedock/domain-manager/{id}/email-routing/rules/{ruleId}/toggle', 'CaddyDomainManager\Controllers\EmailRoutingController@toggleRule')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.toggle-rule');

// Actualizar catch-all
Route::post('/musedock/domain-manager/{id}/email-routing/catch-all', 'CaddyDomainManager\Controllers\EmailRoutingController@updateCatchAll')
    ->middleware('superadmin')
    ->name('superadmin.email-routing.update-catch-all');

// Apply skin to tenant (AJAX)
Route::post('/musedock/domain-manager/skin/apply', 'CaddyDomainManager\Controllers\DomainManagerController@applySkinToTenant')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.apply-skin');

// Tenant preset management (AJAX)
Route::post('/musedock/domain-manager/{id}/preset/save', 'CaddyDomainManager\Controllers\DomainManagerController@savePresetForTenant')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.preset.save');

Route::post('/musedock/domain-manager/{id}/preset/{presetSlug}/load', 'CaddyDomainManager\Controllers\DomainManagerController@loadPresetForTenant')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.preset.load');

Route::post('/musedock/domain-manager/{id}/preset/{presetSlug}/delete', 'CaddyDomainManager\Controllers\DomainManagerController@deletePresetForTenant')
    ->middleware('superadmin')
    ->name('superadmin.domain-manager.preset.delete');

// ============================================
// SKIN MANAGEMENT (Superadmin)
// ============================================
Route::post('/musedock/themes/skins/{slug}/toggle', 'CaddyDomainManager\Controllers\DomainManagerController@toggleSkin')
    ->middleware('superadmin')
    ->name('superadmin.themes.skins.toggle');

Route::post('/musedock/themes/skins/{slug}/delete', 'CaddyDomainManager\Controllers\DomainManagerController@deleteSkin')
    ->middleware('superadmin')
    ->name('superadmin.themes.skins.delete');

// ============================================
