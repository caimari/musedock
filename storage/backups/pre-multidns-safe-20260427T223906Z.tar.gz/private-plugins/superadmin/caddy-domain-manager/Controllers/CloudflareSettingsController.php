<?php

namespace CaddyDomainManager\Controllers;

use CaddyDomainManager\Services\CloudflareAccountService;
use Screenart\Musedock\Logger;
use Screenart\Musedock\View;
use Exception;

class CloudflareSettingsController
{
    private CloudflareAccountService $accountService;

    public function __construct()
    {
        $this->accountService = new CloudflareAccountService();
    }

    /**
     * Settings page — list all Cloudflare accounts
     */
    public function index(): void
    {
        // Auto-migrate from .env on first visit
        if ($this->accountService->tableExists() && $this->accountService->count() === 0) {
            $migrated = $this->accountService->migrateFromEnvIfNeeded();
            if ($migrated) {
                $flash = 'Cuentas migradas automáticamente desde .env';
            }
        }

        $accounts = $this->accountService->tableExists() ? $this->accountService->getAll() : [];
        $hasEnvFallback = $this->accountService->hasEnvFallback();

        echo View::renderSuperadmin('plugins.caddy-domain-manager.cloudflare-settings', [
            'accounts' => $accounts,
            'hasEnvFallback' => $hasEnvFallback,
            'flash' => $flash ?? null,
        ]);
    }

    /**
     * Store a new Cloudflare account (AJAX)
     */
    public function store(): void
    {
        header('Content-Type: application/json');

        try {
            $name = trim($_POST['name'] ?? '');
            $apiToken = trim($_POST['api_token'] ?? '');
            $accountId = trim($_POST['account_id'] ?? '');
            $role = $_POST['role'] ?? 'domains';
            $sslMode = $_POST['ssl_mode'] ?? 'full';
            $isDefault = !empty($_POST['is_default_for_new_domains']);
            $enabled = !isset($_POST['enabled']) || !empty($_POST['enabled']);

            if (empty($name) || empty($apiToken)) {
                echo json_encode(['success' => false, 'error' => 'Name and API Token are required']);
                return;
            }

            if (!in_array($role, ['primary', 'domains', 'readonly'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid role']);
                return;
            }

            $id = $this->accountService->create([
                'name' => $name,
                'api_token' => $apiToken,
                'account_id' => $accountId,
                'role' => $role,
                'is_default_for_new_domains' => $isDefault,
                'ssl_mode' => $sslMode,
                'enabled' => $enabled,
            ]);

            echo json_encode(['success' => true, 'id' => $id, 'message' => "Account '{$name}' created"]);

        } catch (Exception $e) {
            Logger::error("[CloudflareSettings] Store error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Update an existing account (AJAX)
     */
    public function update(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $data = [];

            if (isset($_POST['name'])) {
                $data['name'] = trim($_POST['name']);
            }
            if (!empty($_POST['api_token'])) {
                $data['api_token'] = trim($_POST['api_token']);
            }
            if (isset($_POST['account_id'])) {
                $data['account_id'] = trim($_POST['account_id']);
            }
            if (isset($_POST['role']) && in_array($_POST['role'], ['primary', 'domains', 'readonly'])) {
                $data['role'] = $_POST['role'];
            }
            if (isset($_POST['is_default_for_new_domains'])) {
                $data['is_default_for_new_domains'] = !empty($_POST['is_default_for_new_domains']);
            }
            if (isset($_POST['ssl_mode'])) {
                $data['ssl_mode'] = $_POST['ssl_mode'];
            }
            if (isset($_POST['enabled'])) {
                $data['enabled'] = !empty($_POST['enabled']);
            }

            $this->accountService->update($id, $data);
            echo json_encode(['success' => true, 'message' => 'Account updated']);

        } catch (Exception $e) {
            Logger::error("[CloudflareSettings] Update error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Delete an account (AJAX)
     */
    public function destroy(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $account = $this->accountService->find($id);
            if (!$account) {
                echo json_encode(['success' => false, 'error' => 'Account not found']);
                return;
            }

            $this->accountService->delete($id);
            echo json_encode(['success' => true, 'message' => "Account '{$account['name']}' deleted"]);

        } catch (Exception $e) {
            Logger::error("[CloudflareSettings] Delete error: " . $e->getMessage());
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Test connection for an account (AJAX)
     */
    public function testConnection(): void
    {
        header('Content-Type: application/json');

        try {
            $apiToken = trim($_POST['api_token'] ?? '');
            $accountIdParam = (int) ($_POST['account_id_db'] ?? 0);

            // If account_id_db is provided, use the stored token
            if ($accountIdParam > 0 && empty($apiToken)) {
                $account = $this->accountService->find($accountIdParam);
                if ($account) {
                    $apiToken = $account['api_token_decrypted'];
                }
            }

            if (empty($apiToken)) {
                echo json_encode(['success' => false, 'error' => 'No API token provided']);
                return;
            }

            $result = $this->accountService->testConnection($apiToken);
            echo json_encode($result);

        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Toggle enabled/disabled for an account (AJAX)
     */
    public function toggleEnabled(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $account = $this->accountService->find($id);
            if (!$account) {
                echo json_encode(['success' => false, 'error' => 'Account not found']);
                return;
            }

            $newState = !$account['enabled'];
            $this->accountService->update($id, ['enabled' => $newState]);

            echo json_encode([
                'success' => true,
                'enabled' => $newState,
                'message' => $newState ? 'Account enabled' : 'Account disabled',
            ]);

        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }

    /**
     * Set an account as default for new domains (AJAX)
     */
    public function setDefault(int $id): void
    {
        header('Content-Type: application/json');

        try {
            $this->accountService->update($id, ['is_default_for_new_domains' => true]);
            echo json_encode(['success' => true, 'message' => 'Default account updated']);

        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
    }
}
