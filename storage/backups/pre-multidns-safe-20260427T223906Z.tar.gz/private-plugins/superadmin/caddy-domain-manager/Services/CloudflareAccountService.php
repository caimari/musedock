<?php

namespace CaddyDomainManager\Services;

use Screenart\Musedock\Database;
use Screenart\Musedock\Logger;
use PDO;
use Exception;

/**
 * CloudflareAccountService
 *
 * CRUD + AES-256-CBC encryption for Cloudflare accounts stored in DB.
 * Handles migration from .env on first access.
 */
class CloudflareAccountService
{
    private PDO $pdo;
    private string $encryptionKey;
    private const CIPHER = 'aes-256-cbc';

    public function __construct()
    {
        $this->pdo = Database::connect();
        $this->encryptionKey = $this->resolveEncryptionKey();
    }

    // ============================================
    // ENCRYPTION
    // ============================================

    private function resolveEncryptionKey(): string
    {
        $key = getenv('APP_ENCRYPTION_KEY') ?: '';
        if (empty($key)) {
            // Fallback: derive from APP_KEY if available
            $appKey = getenv('APP_KEY') ?: '';
            if (!empty($appKey)) {
                $key = hash('sha256', $appKey, true);
                return $key;
            }
            throw new Exception('APP_ENCRYPTION_KEY (or APP_KEY) must be set in .env for token encryption');
        }

        // If key is base64-encoded, decode it
        if (str_starts_with($key, 'base64:')) {
            return base64_decode(substr($key, 7));
        }

        // Hash to ensure 32-byte key
        return hash('sha256', $key, true);
    }

    public function encrypt(string $plaintext): string
    {
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length(self::CIPHER));
        $encrypted = openssl_encrypt($plaintext, self::CIPHER, $this->encryptionKey, OPENSSL_RAW_DATA, $iv);

        if ($encrypted === false) {
            throw new Exception('Encryption failed');
        }

        // Store as base64(iv + encrypted)
        return base64_encode($iv . $encrypted);
    }

    public function decrypt(string $payload): string
    {
        $data = base64_decode($payload);
        if ($data === false) {
            throw new Exception('Invalid encrypted payload');
        }

        $ivLength = openssl_cipher_iv_length(self::CIPHER);
        $iv = substr($data, 0, $ivLength);
        $encrypted = substr($data, $ivLength);

        $decrypted = openssl_decrypt($encrypted, self::CIPHER, $this->encryptionKey, OPENSSL_RAW_DATA, $iv);

        if ($decrypted === false) {
            throw new Exception('Decryption failed — check APP_ENCRYPTION_KEY');
        }

        return $decrypted;
    }

    // ============================================
    // AUTO-MIGRATION FROM .ENV
    // ============================================

    /**
     * If cloudflare_accounts table is empty and .env has tokens, migrate them.
     */
    public function migrateFromEnvIfNeeded(): bool
    {
        $count = (int) $this->pdo->query("SELECT COUNT(*) FROM cloudflare_accounts")->fetchColumn();
        if ($count > 0) {
            return false; // Already has accounts
        }

        $migrated = false;

        // Primary account
        $primaryToken = getenv('CLOUDFLARE_API_TOKEN') ?: '';
        if (!empty($primaryToken)) {
            $primaryAccountId = getenv('CLOUDFLARE_ACCOUNT_ID') ?: '';
            $this->create([
                'name' => 'Primary',
                'api_token' => $primaryToken,
                'account_id' => $primaryAccountId,
                'role' => 'primary',
                'is_default_for_new_domains' => false,
                'ssl_mode' => 'full',
                'enabled' => true,
            ]);
            Logger::info("[CloudflareAccounts] Migrated primary account from .env");
            $migrated = true;
        }

        // Custom domains account
        $customToken = getenv('CLOUDFLARE_CUSTOM_DOMAINS_API_TOKEN') ?: '';
        if (!empty($customToken)) {
            $customAccountId = getenv('CLOUDFLARE_CUSTOM_DOMAINS_ACCOUNT_ID') ?: '';
            $sslMode = getenv('CLOUDFLARE_CUSTOM_DOMAINS_SSL_MODE') ?: 'full';
            $this->create([
                'name' => 'Custom Domains',
                'api_token' => $customToken,
                'account_id' => $customAccountId,
                'role' => 'domains',
                'is_default_for_new_domains' => true,
                'ssl_mode' => $sslMode,
                'enabled' => true,
            ]);
            Logger::info("[CloudflareAccounts] Migrated custom domains account from .env");
            $migrated = true;
        }

        return $migrated;
    }

    // ============================================
    // CRUD
    // ============================================

    public function create(array $data): int
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO cloudflare_accounts (name, api_token, account_id, role, is_default_for_new_domains, ssl_mode, enabled, created_at, updated_at)
            VALUES (:name, :api_token, :account_id, :role, :is_default, :ssl_mode, :enabled, NOW(), NOW())
        ");

        // If marking as default, unset other defaults first
        if (!empty($data['is_default_for_new_domains'])) {
            $this->pdo->exec("UPDATE cloudflare_accounts SET is_default_for_new_domains = 0");
        }

        $stmt->execute([
            'name' => $data['name'],
            'api_token' => $this->encrypt($data['api_token']),
            'account_id' => $data['account_id'] ?? '',
            'role' => $data['role'] ?? 'domains',
            'is_default' => !empty($data['is_default_for_new_domains']) ? 1 : 0,
            'ssl_mode' => $data['ssl_mode'] ?? 'full',
            'enabled' => isset($data['enabled']) ? ($data['enabled'] ? 1 : 0) : 1,
        ]);

        $id = (int) $this->pdo->lastInsertId();
        Logger::info("[CloudflareAccounts] Created account '{$data['name']}' (ID: {$id}, role: {$data['role']})");

        return $id;
    }

    public function update(int $id, array $data): bool
    {
        $fields = [];
        $params = ['id' => $id];

        if (isset($data['name'])) {
            $fields[] = 'name = :name';
            $params['name'] = $data['name'];
        }

        if (isset($data['api_token']) && !empty($data['api_token'])) {
            $fields[] = 'api_token = :api_token';
            $params['api_token'] = $this->encrypt($data['api_token']);
        }

        if (isset($data['account_id'])) {
            $fields[] = 'account_id = :account_id';
            $params['account_id'] = $data['account_id'];
        }

        if (isset($data['role'])) {
            $fields[] = 'role = :role';
            $params['role'] = $data['role'];
        }

        if (isset($data['is_default_for_new_domains'])) {
            if ($data['is_default_for_new_domains']) {
                $this->pdo->exec("UPDATE cloudflare_accounts SET is_default_for_new_domains = 0");
            }
            $fields[] = 'is_default_for_new_domains = :is_default';
            $params['is_default'] = $data['is_default_for_new_domains'] ? 1 : 0;
        }

        if (isset($data['ssl_mode'])) {
            $fields[] = 'ssl_mode = :ssl_mode';
            $params['ssl_mode'] = $data['ssl_mode'];
        }

        if (isset($data['enabled'])) {
            $fields[] = 'enabled = :enabled';
            $params['enabled'] = $data['enabled'] ? 1 : 0;
        }

        if (empty($fields)) {
            return false;
        }

        $fields[] = 'updated_at = NOW()';

        $sql = "UPDATE cloudflare_accounts SET " . implode(', ', $fields) . " WHERE id = :id";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute($params);

        Logger::info("[CloudflareAccounts] Updated account ID {$id}");
        return $result;
    }

    public function delete(int $id): bool
    {
        $stmt = $this->pdo->prepare("DELETE FROM cloudflare_accounts WHERE id = :id");
        $result = $stmt->execute(['id' => $id]);
        Logger::info("[CloudflareAccounts] Deleted account ID {$id}");
        return $result;
    }

    public function find(int $id): ?array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM cloudflare_accounts WHERE id = :id");
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            return null;
        }

        return $this->decryptRow($row);
    }

    public function getAll(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM cloudflare_accounts ORDER BY role ASC, name ASC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($row) => $this->decryptRow($row), $rows);
    }

    public function getEnabled(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM cloudflare_accounts WHERE enabled = 1 ORDER BY role ASC, name ASC");
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($row) => $this->decryptRow($row), $rows);
    }

    public function getDefaultForNewDomains(): ?array
    {
        $stmt = $this->pdo->query("SELECT * FROM cloudflare_accounts WHERE is_default_for_new_domains = 1 AND enabled = 1 LIMIT 1");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            // Fallback: first enabled account with role 'domains'
            $stmt = $this->pdo->query("SELECT * FROM cloudflare_accounts WHERE role = 'domains' AND enabled = 1 LIMIT 1");
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
        }

        return $row ? $this->decryptRow($row) : null;
    }

    public function getByRole(string $role): array
    {
        $stmt = $this->pdo->prepare("SELECT * FROM cloudflare_accounts WHERE role = :role AND enabled = 1 ORDER BY name ASC");
        $stmt->execute(['role' => $role]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return array_map(fn($row) => $this->decryptRow($row), $rows);
    }

    /**
     * Test if a token is valid by calling Cloudflare's /user/tokens/verify
     */
    public function testConnection(string $apiToken): array
    {
        $ch = curl_init('https://api.cloudflare.com/client/v4/user/tokens/verify');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $apiToken,
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 10,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'error' => "Connection error: {$error}"];
        }

        $decoded = json_decode($response, true);

        if ($httpCode === 200 && ($decoded['success'] ?? false)) {
            return [
                'success' => true,
                'status' => $decoded['result']['status'] ?? 'active',
            ];
        }

        $errorMsg = $decoded['errors'][0]['message'] ?? "HTTP {$httpCode}";
        return ['success' => false, 'error' => $errorMsg];
    }

    // ============================================
    // HELPERS
    // ============================================

    /**
     * Check if the cloudflare_accounts table exists
     */
    public function tableExists(): bool
    {
        $driver = $this->pdo->getAttribute(PDO::ATTR_DRIVER_NAME);

        try {
            if ($driver === 'mysql') {
                $stmt = $this->pdo->query("SHOW TABLES LIKE 'cloudflare_accounts'");
                return (bool) $stmt->fetch();
            } else {
                $stmt = $this->pdo->prepare("SELECT table_name FROM information_schema.tables WHERE table_name = 'cloudflare_accounts' AND table_schema = 'public'");
                $stmt->execute();
                return (bool) $stmt->fetch();
            }
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Get accounts count
     */
    public function count(): int
    {
        return (int) $this->pdo->query("SELECT COUNT(*) FROM cloudflare_accounts")->fetchColumn();
    }

    /**
     * Check if there are .env fallback credentials available
     */
    public function hasEnvFallback(): bool
    {
        $token = getenv('CLOUDFLARE_CUSTOM_DOMAINS_API_TOKEN') ?: '';
        $accountId = getenv('CLOUDFLARE_CUSTOM_DOMAINS_ACCOUNT_ID') ?: '';
        return !empty($token) && !empty($accountId);
    }

    /**
     * Get .env fallback credentials (for use when table is empty)
     */
    public function getEnvFallback(): array
    {
        return [
            'primary' => [
                'api_token' => getenv('CLOUDFLARE_API_TOKEN') ?: '',
                'account_id' => getenv('CLOUDFLARE_ACCOUNT_ID') ?: '',
            ],
            'domains' => [
                'api_token' => getenv('CLOUDFLARE_CUSTOM_DOMAINS_API_TOKEN') ?: '',
                'account_id' => getenv('CLOUDFLARE_CUSTOM_DOMAINS_ACCOUNT_ID') ?: '',
                'ssl_mode' => getenv('CLOUDFLARE_CUSTOM_DOMAINS_SSL_MODE') ?: 'full',
            ],
        ];
    }

    private function decryptRow(array $row): array
    {
        try {
            $row['api_token_decrypted'] = $this->decrypt($row['api_token']);
        } catch (Exception $e) {
            // Token may be plaintext (pre-encryption) or corrupted
            Logger::warning("[CloudflareAccounts] Could not decrypt token for account ID {$row['id']}: {$e->getMessage()}");
            $row['api_token_decrypted'] = '';
        }
        // Mask the token for display
        $raw = $row['api_token_decrypted'];
        $row['api_token_masked'] = !empty($raw) ? substr($raw, 0, 8) . '••••••••' . substr($raw, -4) : '(error)';

        return $row;
    }
}
