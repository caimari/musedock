<?php
/**
 * Install script for Caddy Domain Manager plugin
 *
 * Este archivo se ejecuta cuando el plugin se instala.
 * - Ejecuta las migraciones
 * - NO registra el menú (eso lo hace activate.php)
 */

namespace CaddyDomainManager;

use Screenart\Musedock\Database;
use Screenart\Musedock\Logger;
use PDO;

// Verificar contexto
if (!defined('APP_ROOT')) {
    exit('No direct access allowed');
}

echo "[Caddy Domain Manager] Ejecutando instalación...\n";

try {
    // Ejecutar migraciones
    $migrations = [
        '001_add_caddy_columns_to_tenants.php' => Migrations\AddCaddyColumnsToTenants::class,
        '002_create_cloudflare_accounts_table.php' => Migrations\CreateCloudflareAccountsTable::class,
    ];

    foreach ($migrations as $file => $class) {
        $migrationFile = __DIR__ . '/migrations/' . $file;
        if (file_exists($migrationFile)) {
            require_once $migrationFile;
            $migration = new $class();
            $migration->up();
            echo "[Caddy Domain Manager] Migration {$file} executed\n";
        } else {
            echo "[Caddy Domain Manager] Warning: Migration file not found: {$file}\n";
        }
    }

    Logger::log("[Caddy Domain Manager] Plugin instalado correctamente", 'INFO');

} catch (\Exception $e) {
    Logger::log("[Caddy Domain Manager] Error en instalación: " . $e->getMessage(), 'ERROR');
    echo "[Caddy Domain Manager] Error: " . $e->getMessage() . "\n";
}
