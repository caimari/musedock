<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', themeConfig('name', 'Mi Sitio'))</title>

    {{-- Estilos desde theme.json --}}
    @foreach ((array) themeConfig('styles', []) as $css)
        <link href="{{ $css }}" rel="stylesheet">
    @endforeach

    {{-- Rutas de assets automáticas para main.css y main.js --}}
    @php
        $tenant     = tenant();
        $themeSlug  = $tenant['theme'] ?? setting('default_theme', 'default');
        $themePath  = ($tenant ? "tenant_{$tenant['id']}/" : "") . $themeSlug;

        $mainCssWeb  = "/themes/{$themePath}/assets/css/main.css";
        $mainJsWeb   = "/themes/{$themePath}/assets/js/main.js";

        $mainCssPath = __DIR__ . "/../../../../themes/{$themePath}/assets/css/main.css";
        $mainJsPath  = __DIR__ . "/../../../../themes/{$themePath}/assets/js/main.js";
    @endphp

    @if (file_exists($mainCssPath))
        <link href="{{ $mainCssWeb }}" rel="stylesheet">
    @endif

    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
            color: #222;
        }
    </style>

    @yield('head')
</head>
<body>

    <main>
        @yield('content')
    </main>

    {{-- Scripts desde theme.json --}}
    @foreach ((array) themeConfig('scripts', []) as $js)
        <script src="{{ $js }}"></script>
    @endforeach

    {{-- Carga automática de main.js si existe --}}
    @if (file_exists($mainJsPath))
        <script src="{{ $mainJsWeb }}"></script>
    @endif

    @yield('scripts')
</body>
</html>
