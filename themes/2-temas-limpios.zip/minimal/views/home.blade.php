@extends('layouts.minimal')

@section('title', 'Bienvenido a ' . themeConfig('name', 'Mi Sitio'))

@section('content')
    <header style="text-align:center; margin-bottom: 2rem;">
        <h1>Bienvenido a {{ themeConfig('name', 'Mi Sitio') }}</h1>
        <p>{{ themeConfig('description', 'Este es tu nuevo sitio CMS') }}</p>
    </header>

    <section style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem;">
        <article style="background: #fff; padding: 1.5rem; border-radius: 8px; box-shadow: 0 1px 4px rgba(0,0,0,0.05);">
            <h2>Contenido destacado</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce eget nisl vel erat malesuada luctus.</p>
        </article>
        <article style="background: #fff; padding: 1.5rem; border-radius: 8px; box-shadow: 0 1px 4px rgba(0,0,0,0.05);">
            <h2>Blog o noticias</h2>
            <p>Publica tus novedades aquí o enlaza a un módulo de publicaciones.</p>
        </article>
    </section>
@endsection
