document.addEventListener("DOMContentLoaded", function () {
    console.log("JS del tema cargado correctamente.");

    const btns = document.querySelectorAll('.btn');
    btns.forEach(btn => {
        btn.addEventListener('click', () => {
            alert('Haz hecho clic en un botón del tema.');
        });
    });
});
