@extends('layouts.app')

@section('title', 'Inicio')

@section('content')
<div class="container mt-5">
    <h1 class="display-4">Bienvenido a tu sitio</h1>
    <p class="lead">Este es el inicio del tema. Puedes editarlo visualmente desde el panel Superadmin.</p>

    <a href="#" class="btn btn-primary">Saber más</a>
</div>
@endsection

