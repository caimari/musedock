<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', themeConfig('name', 'Mi Sitio'))</title>

    {{-- Bootstrap si el tema lo requiere --}}
    @if (themeConfig('bootstrap', true))
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    @endif

    {{-- Estilos definidos por el tema --}}
    @foreach ((array) themeConfig('styles', []) as $css)
        <link href="{{ $css }}" rel="stylesheet">
    @endforeach

    @yield('head')
</head>
<body>

    <div class="container py-4">
        @yield('content')
    </div>

    {{-- Scripts definidos por el tema --}}
    @foreach ((array) themeConfig('scripts', []) as $js)
        <script src="{{ $js }}"></script>
    @endforeach

    @yield('scripts')
</body>
</html>
